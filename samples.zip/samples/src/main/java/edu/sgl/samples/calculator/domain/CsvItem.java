package edu.sgl.samples.calculator.domain;

public class CsvItem {

  private String item;

}
