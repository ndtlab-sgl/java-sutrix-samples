package edu.sgl.samples.calculator;

public interface ICalculator<T> {

  T calculate(String valueStr);

}
