package edu.sgl.students.data;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;

import edu.sgl.students.domain.Student;

public class StudentListBuilder {

  public static List<Student> buildRandomStudents(int maxValue) {
    final List<Student> students = new ArrayList<>();
    for (int i = 0; i < maxValue; i++) {
      final Student student = new Student(
          RandomStringUtils.randomAlphanumeric(5),
          RandomStringUtils.randomAlphabetic(10),
          RandomStringUtils.randomAlphabetic(10),
          RandomUtils.nextInt(18, 22),
          RandomUtils.nextDouble(0, 10));
      students.add(student);
    }
    return students;
  }

  public  static List<Student> buildRandomDupplicatedStudents(int maxValue) {
    final List<Student> students = buildRandomStudents(maxValue);
    final List<Student> dupplicatedStudents = new ArrayList<>(students);
    students.addAll(students);
    return dupplicatedStudents;
  }
}
