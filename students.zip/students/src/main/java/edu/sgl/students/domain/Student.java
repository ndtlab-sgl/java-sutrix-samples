package edu.sgl.students.domain;

import org.apache.commons.lang3.StringUtils;

public class Student {

  private String id;

  private String firstName;

  private String lastName;

  private int age;

  private double avgScore;

  public Student(String id, String firstName, String lastName, int age, double score) {
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
    this.avgScore = score;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public int getAge() {
    return age;
  }

  public void setAge(int age) {
    this.age = age;
  }

  public double getAvgScore() {
    return avgScore;
  }

  public void setAvgScore(double avgScore) {
    this.avgScore = avgScore;
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder('[');
    sb.append(getId()).append(StringUtils.SPACE)
    .append(getFirstName()).append(StringUtils.SPACE)
    .append(getLastName()).append(StringUtils.SPACE)
    .append(getAge()).append(StringUtils.SPACE)
    .append(getAvgScore()).append(StringUtils.SPACE);
    return sb.append(']').toString();
  }
}
