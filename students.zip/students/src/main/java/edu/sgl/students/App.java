package edu.sgl.students;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import edu.sgl.students.data.StudentListBuilder;
import edu.sgl.students.domain.Student;

/**
 * @author <Please fill your name at here>
 */
public class App {

  private static final int MAX_VALUE = 30;

  public static void main(String...strings) {
    final List<Student> originalStudents = StudentListBuilder.buildRandomStudents(MAX_VALUE);
    printResult("Original Student List", originalStudents);

    System.out.println("###################################################################");

    sortIdByAsc(originalStudents);
    printResult("After sort by ID ASC", originalStudents);

  }

  private static void sortIdByAsc(final List<Student> students) {
    final Comparator<Student> sorting = (s1, s2) -> s1.getId().compareTo(s2.getId());
    Collections.sort(students, sorting);
  }

  private static void printResult(final String title, final Collection<Student> students) {
    System.out.println(title);
    for (Student student : students) {
      System.out.println("Student = " + student.toString());
    }
  }

}
