INSERT INTO hibernate_sequence (next_val) VALUES 
(1)
;