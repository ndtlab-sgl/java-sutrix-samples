package com.demo.strings.collections;

public class Student {

  private String id;

  private int age;

  private String name;

  public Student(String id, String name, int age) {
    this.id = id;
    this.name = name;
    this.age = age;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public int getAge() {
    return age;
  }

  public void setAge(int age) {
    this.age = age;
  }



  public String getName() {
    return name;
  }



  public void setName(String name) {
    this.name = name;
  }



  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder("[ ");
    sb.append("ID = ").append(id).append(", ");
    sb.append("Name = ").append(name).append(", ");
    sb.append("Age = ").append(age).append(" ]");
    return sb.toString();
  }

  @Override
  public boolean equals(Object obj) {
    Student student = (Student) obj;
    return id.equals(student.id) && name.equals(student.name);
  }

}
