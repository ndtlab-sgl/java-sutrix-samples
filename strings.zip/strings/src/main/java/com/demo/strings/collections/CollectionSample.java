package com.demo.strings.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * CollectionSample.
 *
 * @author Thi Nguyen
 */
public class CollectionSample {

  private static Collection<Student> buildStudentsByList() {
    final List<Student> students = new ArrayList<>();
    students.add(new Student("A01", "Nguyen Van A", 18));
    students.add(new Student("A02", "Nguyen Van B", 20));
    students.add(new Student("A03", "Nguyen Van C", 19));
    students.add(new Student("A04", "Nguyen Van D", 18));

    students.add(new Student("A01", "Nguyen Van B", 18));
    return students;
  }

  private static Collection<Student> buildStudentsBySet() {
    final Set<Student> students = new HashSet<>();
    students.add(new Student("A01", "Nguyen Van A", 18));
    students.add(new Student("A02", "Nguyen Van B", 20));
    students.add(new Student("A03", "Nguyen Van C", 19));
    students.add(new Student("A04", "Nguyen Van D", 18));

    students.add(new Student("A01", "Nguyen Van B", 18));
    return students;
  }

  private static Map<String, Student> buildStudentsByMap() {
    final Map<String, Student> studentMap = new HashMap<>();
    final Collection<Student> students = buildStudentsByList();
    students.stream().forEach(student -> studentMap.put(student.getId(), student));
    return studentMap;
  }

  public static void main(String...strings) {
    Map<String, Student> students = buildStudentsByMap();
    students.forEach((key, value) -> System.out.println(key + " " + value));
  }

}
