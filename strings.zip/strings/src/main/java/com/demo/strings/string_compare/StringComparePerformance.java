package com.demo.strings.string_compare;

public class StringComparePerformance {

  private static final String APPEND_TEXT = "text";

  private static final int SIZE = 100000;

  private static void appendStringBySize(int size) {
    String str = null;
    for (int i = 0; i < size; i++) {
      str += APPEND_TEXT;
    }
    //System.out.println("Result of appendStringBySize = " + str);
  }

  private static void appendStringBufferBySize(int size) {
    StringBuffer strBuffer = new StringBuffer();
    for (int i = 0; i < size; i++) {
      strBuffer.append(APPEND_TEXT);
    }
    //System.out.println("Result of appendStringBufferBySize = " + strBuffer.toString());
  }

  private static void appendStringBuilderBySize(int size) {
    StringBuilder strBuilder = new StringBuilder();
    for (int i = 0; i < size; i++) {
      strBuilder.append(APPEND_TEXT);
    }
    //System.out.println("Result of appendStringBuilderBySize = " + strBuilder.toString());
  }

  public static void main(String...strings) {
    long start = System.currentTimeMillis();
    appendStringBuilderBySize(SIZE);
    long end = System.currentTimeMillis() - start;
    System.out.println(String.format("Run appendStringBuilderBySize in %d ms", end));

    start = System.currentTimeMillis();
    appendStringBufferBySize(SIZE);
    end = System.currentTimeMillis() - start;
    System.out.println(String.format("Run appendStringBufferBySize in %d ms", end));

    start = System.currentTimeMillis();
    appendStringBySize(SIZE);
    end = System.currentTimeMillis() - start;
    System.out.println(String.format("Run appendStringBySize in %d ms", end));
  }
}
